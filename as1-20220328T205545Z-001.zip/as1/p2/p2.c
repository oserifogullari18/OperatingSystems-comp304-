#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>

#define SIZE 50
#define R 0
#define W 1

int main(){
    char message_a[SIZE];
    char r_message[SIZE];
    //For sys/time.h
    struct timeval tv; 
    time_t sec;
    //For time.h
    struct tm *tptr; 

    //Creating the message A to B of current time
    gettimeofday(&tv, NULL);
    sec = tv.tv_sec;
    tptr = localtime(&sec);
    strftime(message_a, SIZE, "%H : %M : %S", tptr);

    //Creating pipes between the process A and B
    int pipe_ab[2], pipe_ba[2];
    if(pipe(pipe_ab) == -1){
        printf("Pipe A to B failed\n"); //Exception handling
        return 1;
    }
    if(pipe(pipe_ba) == -1){
        printf("Pipe B to A failed\n"); //Exception handling
        return 1;
    }

    //Creating the process B
    pid_t pid1 = fork();
    //In case of an error
    if(pid1 == -1){
        printf("Error while creating the process B\n");
    }
    //Process A
    else if(pid1 > 0){
        //Closing the unused ends
        close(pipe_ab[R]);
        close(pipe_ba[W]);
        //Sending message to B
        write(pipe_ab[W], message_a, SIZE);
        //Receiving message from B
        read(pipe_ba[R], r_message, SIZE);
        //Printing the received time from B
        printf("The time received from B to A is: %s\n", r_message);
        //Killing the process B
        kill(pid1, SIGTERM);
    }
    //Process B
    else{
        //Closing the unused ends
        close(pipe_ba[R]);
        close(pipe_ab[W]);
        //Receiving message from A
        read(pipe_ab[R], r_message, SIZE);
        //Printing the receieved time from A
        printf("The time received from A to B is: %s\n", r_message);
        sleep(3);

        //Creating the message B to C of current time
        char message_b[SIZE];
        gettimeofday(&tv, NULL);
        sec = tv.tv_sec;
        tptr = localtime(&sec);
        strftime(message_b, SIZE, "%H : %M : %S", tptr);

        //Creating the pipes between the process B and C
        int pipe_bc[2], pipe_cb[2];
        if(pipe(pipe_bc) == -1){
            printf("Pipe B to C failed\n"); //Exception handling
            return 1;
        }
        if(pipe(pipe_cb) == -1){
            printf("Pipe C to B failed\n"); //Exception handling
            return 1;
        }

        //Creating the process C
        pid_t pid2 = fork();
        if(pid2 == -1){
            printf("Error while creating the process C\n"); //Exception handling
        }

        //Process B
        if(pid2 > 0){
            //Closing the unused ends
            close(pipe_bc[R]);
            close(pipe_cb[W]);
            //Sending message to C
            write(pipe_bc[W], message_b, SIZE);
            //Receiving message from C
            read(pipe_cb[R], r_message, SIZE);
            //Printing the received time from C
            printf("The time received from C to B is: %s\n", r_message);
            //Killing the process C
            kill(pid2, SIGTERM);
            sleep(3);

            //Creating the message B to A of current time
            gettimeofday(&tv, NULL);
            sec = tv.tv_sec;
            tptr = localtime(&sec);
            strftime(message_b, SIZE, "%H : %M : %S", tptr); 
            //Sending the message B to A
            write(pipe_ba[W], message_b, SIZE);          
        }
        //Process C
        else{
            //Closing the unused ends
            close(pipe_cb[R]);
            close(pipe_bc[W]);
            //Receiving message from B
            read(pipe_bc[R], r_message, SIZE);
            //Printing the received time from B
            printf("The time received from B to C is: %s\n", r_message);
            sleep(3);

            //Creating message C to B
            char message_c[SIZE];
            gettimeofday(&tv, NULL);
            sec = tv.tv_sec;
            tptr = localtime(&sec);
            strftime(message_c, SIZE, "%H : %M : %S", tptr); 
            //Sending the message C to B
            write(pipe_cb[W], message_c, SIZE); 
        }

    }

}