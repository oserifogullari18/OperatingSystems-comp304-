1) Time is calculated and message prepared in A
2) Pipes prepared between A and B
3) Process B is created in A
4) Process A is coded
5) Process B is coded and the steps in A is replied for creating process C
6) Process C returned the current time and program went to beginning
