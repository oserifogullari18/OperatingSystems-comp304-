#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();
    if(pid == -1){//Exception handling
        printf("Task failed\n");
    }
    else if(pid == 0){
        execlp("ps", "ps", "f", NULL);
    }
    else{
        wait(NULL);
        printf("Child finished execution\n");
    }

}