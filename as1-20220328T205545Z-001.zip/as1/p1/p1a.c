#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
    int level = 0;
    printf("Base Process ID: %d, level: %d\n", getpid(), level) ;
    
    int i;

    for(i=0; i<4; i++){
        if(fork() == 0){
            level++;//Level increasing for the child after fork
            printf("Process ID: %d, Parent ID: %d, level: %d\n", getpid(), getppid(), level) ;
        }
        else{
            wait(NULL);//To avoid to kill parent process
        }
    }
    
    return 0;
}