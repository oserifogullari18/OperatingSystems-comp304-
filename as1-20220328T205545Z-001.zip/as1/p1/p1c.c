#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>

int main(){
    pid_t pid = fork();
    if(pid == -1){
        printf("Task failed");
    }
    else if(pid > 0){
        sleep(5); //To make child zombie
        wait(NULL);
    }
    else{
        exit(0);
    }
}