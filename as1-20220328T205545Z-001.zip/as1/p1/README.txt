Part a) I printed only the children which created current fork and increased the level after the fork.
Part b) execlp has 4 arguments. Third argument is argument of the secon argument which is the system call we want to make.
Part c) Parent process sleeps for 5 seconds to make the child process zombie
