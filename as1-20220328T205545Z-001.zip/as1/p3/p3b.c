#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/stat.h>
#include <linux/moduleparam.h>
#include <linux/sched.h>
#include <linux/proc_fs.h>

//To pass argument to the kernel
static pid_t input = -3;
module_param(input, pid_t, S_IRUGO);
MODULE_PARM_DESC(input, "A pid_t value");

int partb_init(void){
    int valid = 0;//To understand pid is valid or not
    struct task_struct *task;
    struct task_struct *parent;
    struct task_struct *node;
    struct list_head *list;
    if(input < 0){
        printk(KERN_INFO "Please enter a valid process ID\n");
    }

    else{
        for_each_process(task){
            if(input == task->pid){ //Task found
                valid = 1; //Pid is provided
                parent = task->parent;
                //Outputing the PID, parent's ID and executable name of the process
                printk(KERN_INFO "PID: %d, Parent ID: %d, Executable Name: %s, Siblings:\n", task->pid, parent->pid, task->comm);
                //Outputing the siblings of the process
                list_for_each(list, &parent->children){
                    node = list_entry(list, struct task_struct, sibling);
                    if(node->pid != input){//To not print the task itself
                        printk(KERN_INFO "PID: %d, Executable Name: %s\n",node->pid, node->comm);
                    }
                }
            }
        }
        if(valid == 0){
            printk(KERN_INFO "Process ID is not provided\n");
        }
    }
}

void partb_exit(void){
    printk(KERN_INFO "Removing Module\n");
}

module_init(partb_init);
module_exit(partb_exit);

MODULE_LICENSE( "GPL");
MODULE_DESCRIPTION( "Exercise for COMP304");
MODULE_AUTHOR("Your Name");