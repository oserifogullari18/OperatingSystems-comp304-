Part a I) Steps in the book is repeated
Part a II) Birthday struct is created and arbitrary dates is added to list. The list is sended to the kernel log in init. The list is deleted in exit.
Part b) Input is the pid which we want to search. It is checked for validation then searched in the tasks. If the input is equal one of the task's pid the program will send its information to kernel log. If it is not it will send the error message to the kernel log.
